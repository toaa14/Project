
let el = document.querySelector(".scroller");
let height = document.documentElement.scrollHeight - document.documentElement.clientHeight ;

window.addEventListener("scroll" , () => {

    let scrollTop = document.documentElement.scrollTop ;
    el.style.width = `${(scrollTop / height)*100}%`
});

let mainimage = document.querySelector("img");
let namee = document.querySelector(".name");
var des = document.getElementById("mypara");
var imgs=["imgs/photo-4.jpg","imgs/photo-5.jpg","imgs/photo-6.jpg"];
var name_des=['الـمـهندس عادل' , 'المهندس جوزيف', "الــشــيــف بـوراكــ"];
var info=['هناك  مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال "lorem ipsum" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.'
        ,'هناك حقيقة  منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال "lorem ipsum" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.',
    "وُلد الشيف التركي في 24 مارس 1994. ويلقب بـ CZN Burak، هو طاهٍ وصاحب مطعم تركي يمتلك حضارات سفرة هاتاي وأكساراي. أسلوبه في إعداد وتقديم الوصفات التركية جعله مشهورًا على الإنترنت. حيث انه واصل تعليمه في كلية التعليم المفتوح وقرر مواصلة مهنة جده في سن مبكرة.بعد أن بدأ بتشغيل مطعم صغير تابع لجده في هاتاي افتتح فرعًا في اسطنبول. نجحت ظاهرة بوراك أوزدمير المبتسم الجديدة على وسائل التواصل الاجتماعي بمقاطع الفيديو والصور التي يشاركها على وسائل التواصل الاجتماعي في الترويج لحضارات هاتاي سوفراسي على وسائل التواصل الاجتماعي."
];
var num=0;

function next(){
    num++;
    if(num>=imgs.length)
    {
        num=0;
        mainimage.src=imgs[num];
        namee.innerHTML = name_des[num]
        des.innerHTML = info[num];
    }
    else
    {
        mainimage.src=imgs[num]
        namee.innerHTML = name_des[num]
        des.innerHTML = info[num];
    }
};
function back(){
    num--;
    if(num<0){
        num=imgs.length-1;
        mainimage.src=imgs[num]
        namee.innerHTML = name_des[num]
        des.innerHTML = info[num];
    }
    else
    {
        mainimage.src=imgs[num]
        namee.innerHTML = name_des[num]
        des.innerHTML = info[num];
    }
};
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
    panel.style.maxHeight = null;
    } else {
    panel.style.maxHeight = panel.scrollHeight + "px";
    }
});
}